const isServedOverHttp = window.location.protocol.startsWith('http');

// --- WAF RULESETS DATA STORE ---
let nextRuleId = 5;
let wafRulesets = [
    { id:1, enabled:true, name:'OWASP Top 10 Core Rules', description:'Protects against SQLi, XSS, LFI, RFI, and other common vulnerabilities.', action:'Block', count:482, category:'owasp', isCustom:false },
    { id:2, enabled:true, name:'Bad Bot Protection', description:'Blocks known malicious user agents, scrapers, and automated scanning tools.', action:'Challenge (Captcha)', count:1024, category:'bots', isCustom:false },
    { id:3, enabled:false, name:'Rate Limiting (Strict)', description:'Limits requests to 100 per minute per IP to mitigate DoS and brute forcing.', action:'Block', count:1, category:'owasp', isCustom:false },
    { id:4, enabled:true, name:'Custom: Block Admin Path', description:'Blocks access to /admin/* from non-internal IP ranges.', action:'Block', count:1, category:'custom', isCustom:true }
];
let activeFilter = 'all';
let searchQuery = '';

async function loadRulesFromBackend() {
    if (!isServedOverHttp) return;
    try {
        const res = await fetch('/api/rulesets');
        if (res.ok) {
            wafRulesets = await res.json();
            renderRulesTable();
        }
    } catch (err) {
        console.warn('[Backend] Failed to load rulesets from server, using local data', err);
    }
}

function getFilteredRules() {
    return wafRulesets.filter(r => {
        const matchCat = activeFilter === 'all' || r.category === activeFilter;
        const matchSearch = !searchQuery || r.name.toLowerCase().includes(searchQuery) || r.description.toLowerCase().includes(searchQuery);
        return matchCat && matchSearch;
    });
}

function renderRulesTable() {
    const tbody = document.getElementById('rules-table-body');
    if (!tbody) return;
    const filtered = getFilteredRules();
    const actions = ['Block', 'Log Only', 'Challenge (Captcha)'];
    tbody.innerHTML = filtered.map(r => {
        const toggleOn = r.enabled;
        const toggleCls = toggleOn ? 'bg-primary/20 border-primary/50 hover:bg-primary/30' : 'bg-white/5 border-white/10 hover:bg-white/10';
        const dotCls = toggleOn ? 'bg-primary right-0.5' : 'bg-zinc-500 left-0.5';
        const nameCls = toggleOn ? 'text-white' : 'text-zinc-500';
        const descCls = toggleOn ? 'text-zinc-400' : 'text-zinc-600';
        const countCls = toggleOn ? '' : 'text-zinc-600';
        const selDisabled = toggleOn ? '' : 'disabled';
        const selTextCls = toggleOn ? 'text-white focus:border-primary' : 'text-zinc-500';
        const customBadge = r.isCustom ? ' <span class="badge badge-blue">Custom</span>' : '';
        const deleteBtn = r.isCustom ? `<button data-delete-id="${r.id}" class="text-zinc-600 hover:text-red-400 transition p-1" title="Delete"><svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path></svg></button>` : '';
        const opts = actions.map(a => `<option ${a===r.action?'selected':''}>${a}</option>`).join('');
        return `<tr class="table-row group"><td class="px-6 py-4"><div data-toggle-id="${r.id}" class="w-8 h-4 ${toggleCls} rounded-full relative cursor-pointer border transition-colors"><div class="w-3 h-3 ${dotCls} rounded-full absolute top-0.5 shadow"></div></div></td><td class="px-6 py-4 ${nameCls} font-medium flex items-center gap-2">${r.name}${customBadge}</td><td class="px-6 py-4 ${descCls} truncate max-w-xs">${r.description}</td><td class="px-6 py-4"><select data-action-id="${r.id}" class="bg-black/50 border border-white/10 rounded px-2 py-1 text-xs ${selTextCls} focus:outline-none" ${selDisabled}>${opts}</select></td><td class="px-6 py-4 text-right font-mono tabular-nums ${countCls}">${r.count.toLocaleString()}</td><td class="px-6 py-4 text-right">${deleteBtn}</td></tr>`;
    }).join('');
    attachRulesListeners();
}

function attachRulesListeners() {
    document.querySelectorAll('[data-toggle-id]').forEach(el => {
        el.addEventListener('click', async () => {
            const id = parseInt(el.dataset.toggleId);
            const rule = wafRulesets.find(r => r.id === id);
            if (rule) { 
                rule.enabled = !rule.enabled; 
                renderRulesTable(); 
                if (isServedOverHttp) {
                    try {
                        await fetch(`/api/rulesets/${id}/toggle`, { method: 'PATCH' });
                    } catch (err) {
                        console.error('[Backend] Failed to toggle rule', err);
                    }
                }
            }
        });
    });
    document.querySelectorAll('[data-action-id]').forEach(el => {
        el.addEventListener('change', async () => {
            const id = parseInt(el.dataset.actionId);
            const rule = wafRulesets.find(r => r.id === id);
            if (rule) { 
                rule.action = el.value; 
                if (isServedOverHttp) {
                    try {
                        await fetch(`/api/rulesets/${id}`, {
                            method: 'PATCH',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify({ action: el.value })
                        });
                    } catch (err) {
                        console.error('[Backend] Failed to update rule action', err);
                    }
                }
            }
        });
    });
    document.querySelectorAll('[data-delete-id]').forEach(el => {
        el.addEventListener('click', async () => {
            const id = parseInt(el.dataset.deleteId);
            const rule = wafRulesets.find(r => r.id === id);
            if (rule && rule.isCustom) { 
                wafRulesets = wafRulesets.filter(r => r.id !== id); 
                renderRulesTable(); 
                if (isServedOverHttp) {
                    try {
                        await fetch(`/api/rulesets/${id}`, { method: 'DELETE' });
                    } catch (err) {
                        console.error('[Backend] Failed to delete rule', err);
                    }
                }
            }
        });
    });
}

document.addEventListener('DOMContentLoaded', () => {
    // Tab filters
    document.querySelectorAll('.rules-tab').forEach(tab => {
        tab.addEventListener('click', () => {
            document.querySelectorAll('.rules-tab').forEach(t => { t.classList.remove('text-white','bg-white/10','rounded','shadow-sm'); t.classList.add('text-zinc-500'); });
            tab.classList.remove('text-zinc-500'); tab.classList.add('text-white','bg-white/10','rounded','shadow-sm');
            activeFilter = tab.dataset.cat;
            renderRulesTable();
        });
    });
    // Search
    const searchInput = document.getElementById('rules-search');
    if (searchInput) { searchInput.addEventListener('input', () => { searchQuery = searchInput.value.toLowerCase(); renderRulesTable(); }); }
    // Create custom rule
    const createBtn = document.getElementById('create-rule-btn');
    if (createBtn) {
        createBtn.addEventListener('click', async () => {
            const name = prompt('Rule name (e.g. Block /uploads):');
            if (!name) return;
            const desc = prompt('Description:') || 'Custom rule created by admin.';
            
            if (isServedOverHttp) {
                try {
                    const res = await fetch('/api/rulesets', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ name, description: desc })
                    });
                    if (res.ok) {
                        const newRule = await res.json();
                        wafRulesets.push(newRule);
                        renderRulesTable();
                        return;
                    }
                } catch (err) {
                    console.error('[Backend] Failed to create rule on server', err);
                }
            }
            
            wafRulesets.push({ id: nextRuleId++, enabled: true, name: `Custom: ${name}`, description: desc, action: 'Block', count: 1, category: 'custom', isCustom: true });
            renderRulesTable();
        });
    }
    loadRulesFromBackend();
    renderRulesTable();
});

let localTickInterval = null;

const state = {
    total: 2459802,
    blocked: 142095,
    bw: 84.2,
    latency: 1.2
};

const dom = {
    total: document.getElementById('m-total'),
    blocked: document.getElementById('m-blocked'),
    bw: document.getElementById('m-bw'),
    latency: document.getElementById('m-latency'),
    table: document.getElementById('event-table')
};

let sparkData1 = Array.from({length: 12}, () => Math.random() * 10);
let sparkData2 = Array.from({length: 12}, () => Math.random() * 5);
let sparkData3 = Array.from({length: 12}, () => Math.random() * 20);
let sparkCharts = [];
let trafficChartInst = null;
let vectorChartInst = null;

document.addEventListener('DOMContentLoaded', () => {
    initCharts();
    populateVectors();
    populateAlerts();
    populateOrigin();
    seedTable();
    setupNavigation();
    updateDOM();
    
    // Local simulation fallback
    localTickInterval = setInterval(tickData, 2000);
    
    // Complete Server WebSocket Setup
    if (typeof io !== 'undefined') {
        const socket = io();
        socket.on('connect', () => {
            console.log('[Socket.io] Connected to Nexus WAF Backend Server');
            if (localTickInterval) {
                clearInterval(localTickInterval);
                localTickInterval = null;
            }
        });
        
        socket.on('metrics-update', (data) => {
            state.total = data.total;
            state.blocked = data.blocked;
            state.bw = data.bw;
            state.latency = data.latency;
            
            // Refresh sparklines
            sparkData1.shift(); sparkData1.push(Math.random() * 10);
            sparkData2.shift(); sparkData2.push(Math.random() * 5);
            sparkData3.shift(); sparkData3.push(Math.random() * 20);
            sparkCharts.forEach(c => c.update());
            
            updateDOM();
        });
        
        socket.on('initial-events', (events) => {
            if (dom.table && events && events.length) {
                dom.table.innerHTML = events.map(evt => {
                    return `<tr class="table-row group"><td class="px-6 py-3 text-zinc-400 group-hover:text-zinc-300">${evt.time}</td><td class="px-6 py-3 text-white">${evt.ip}</td><td class="px-6 py-3 text-zinc-300 font-sans text-xs">${evt.ruleName}</td><td class="px-6 py-3 text-zinc-400 group-hover:text-white">${evt.dest}</td><td class="px-6 py-3 text-right"><span class="badge ${evt.badge}">${evt.action}</span></td></tr>`;
                }).join('');
            }
        });
        
        socket.on('new-event', (evt) => {
            if (dom.table) {
                const newRow = `<tr class="table-row group"><td class="px-6 py-3 text-zinc-400 group-hover:text-zinc-300">${evt.time}</td><td class="px-6 py-3 text-white">${evt.ip}</td><td class="px-6 py-3 text-zinc-300 font-sans text-xs">${evt.ruleName}</td><td class="px-6 py-3 text-zinc-400 group-hover:text-white">${evt.dest}</td><td class="px-6 py-3 text-right"><span class="badge ${evt.badge}">${evt.action}</span></td></tr>`;
                dom.table.insertAdjacentHTML('afterbegin', newRow);
                if(dom.table.children.length > 8) dom.table.removeChild(dom.table.lastElementChild);
            }
        });
    }
});

function setupNavigation() {
    const navItems = document.querySelectorAll('.nav-item');
    const views = document.querySelectorAll('.view-section');
    navItems.forEach(item => {
        item.addEventListener('click', (e) => {
            e.preventDefault();
            const targetId = item.getAttribute('data-target');
            navItems.forEach(n => { n.classList.remove('bg-white/10', 'text-white'); n.classList.add('text-zinc-400'); });
            item.classList.remove('text-zinc-400');
            item.classList.add('bg-white/10', 'text-white');
            views.forEach(v => { v.classList.remove('block'); v.classList.add('hidden'); });
            const targetView = document.getElementById(targetId);
            if(targetView) { targetView.classList.remove('hidden'); targetView.classList.add('block'); }
        });
    });
}

function updateDOM() {
    dom.total.innerText = state.total.toLocaleString();
    dom.blocked.innerText = state.blocked.toLocaleString();
    dom.bw.innerHTML = `${state.bw.toFixed(1)} <span class="text-sm font-normal text-zinc-500">GB</span>`;
    dom.latency.innerHTML = `${state.latency.toFixed(1)} <span class="text-sm font-normal text-zinc-500">ms</span>`;
    const rate = ((state.blocked / state.total) * 100).toFixed(2);
    const rateEl = document.getElementById('m-threat-rate');
    if (rateEl) rateEl.textContent = `${rate}% of total traffic`;
    const p99El = document.getElementById('m-p99');
    if (p99El) p99El.textContent = (state.latency * 2 + Math.random() * 0.5).toFixed(1);
}

function initCharts() {
    Chart.defaults.color = '#8F8F8F';
    Chart.defaults.font.family = "'Inter', sans-serif";
    Chart.defaults.plugins.tooltip.backgroundColor = 'rgba(10, 10, 11, 0.9)';
    Chart.defaults.plugins.tooltip.borderColor = 'rgba(255,255,255,0.1)';
    Chart.defaults.plugins.tooltip.borderWidth = 1;
    Chart.defaults.plugins.tooltip.padding = 12;
    Chart.defaults.plugins.tooltip.titleColor = '#EDEDED';
    Chart.defaults.plugins.tooltip.bodyColor = '#a1a1aa';
    Chart.defaults.plugins.tooltip.cornerRadius = 8;
    Chart.defaults.plugins.tooltip.displayColors = false;

    const sparkConfig = (ctxId, data, color) => {
        const ctx = document.getElementById(ctxId).getContext('2d');
        const grad = ctx.createLinearGradient(0, 0, 0, 32);
        grad.addColorStop(0, color.replace('1)', '0.3)'));
        grad.addColorStop(1, color.replace('1)', '0)'));
        return new Chart(ctx, {
            type: 'line',
            data: { labels: Array.from({length: 12}, (_, i) => i), datasets: [{ data: data, borderColor: color, borderWidth: 2, tension: 0.4, pointRadius: 0, fill: true, backgroundColor: grad }] },
            options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false }, tooltip: { enabled: false } }, scales: { x: { display: false }, y: { display: false, min: 0 } }, animation: { duration: 0 } }
        });
    };
    sparkCharts.push(sparkConfig('spark1', sparkData1, 'rgba(74, 222, 128, 1)'));
    sparkCharts.push(sparkConfig('spark2', sparkData2, 'rgba(248, 113, 113, 1)'));
    sparkCharts.push(sparkConfig('spark3', sparkData3, 'rgba(161, 161, 170, 1)'));

    const ctxTraffic = document.getElementById('trafficChart').getContext('2d');
    const gradLegit = ctxTraffic.createLinearGradient(0, 0, 0, 300);
    gradLegit.addColorStop(0, 'rgba(79, 70, 229, 0.3)');
    gradLegit.addColorStop(1, 'rgba(79, 70, 229, 0.0)');
    trafficChartInst = new Chart(ctxTraffic, {
        type: 'line',
        data: { labels: Array.from({length: 24}, (_, i) => `${i.toString().padStart(2, '0')}:00`), datasets: [
            { label: 'Allowed Traffic', data: Array.from({length: 24}, () => Math.floor(Math.random() * 5000 + 3000)), borderColor: '#4F46E5', backgroundColor: gradLegit, borderWidth: 2, tension: 0.4, fill: true, pointRadius: 0, pointHitRadius: 20 },
            { label: 'Blocked Events', data: Array.from({length: 24}, () => Math.floor(Math.random() * 500 + 50)), borderColor: '#ef4444', borderWidth: 2, tension: 0.4, fill: false, pointRadius: 0, pointHitRadius: 20, borderDash: [4, 4] },
            { label: 'Challenged', data: Array.from({length: 24}, () => Math.floor(Math.random() * 200 + 20)), borderColor: '#fb923c', borderWidth: 2, tension: 0.4, fill: false, pointRadius: 0, pointHitRadius: 20, borderDash: [6, 3] }
        ]},
        options: { responsive: true, maintainAspectRatio: false, interaction: { mode: 'index', intersect: false }, plugins: { legend: { display: false } }, scales: { y: { grid: { color: 'rgba(255,255,255,0.05)', drawBorder: false }, border: { dash: [4,4] } }, x: { grid: { display: false }, ticks: { maxTicksLimit: 12 } } } }
    });

    const ctxVector = document.getElementById('vectorChart').getContext('2d');
    vectorChartInst = new Chart(ctxVector, {
        type: 'doughnut',
        data: { labels: ['SQL Injection', 'XSS', 'Path Traversal', 'Rate Limit Exceeded', 'Bad Bot'], datasets: [{ data: [45, 25, 15, 10, 5], backgroundColor: ['#ef4444', '#f59e0b', '#8b5cf6', '#4F46E5', '#3f3f46'], borderWidth: 2, borderColor: '#0A0A0B', hoverOffset: 4 }] },
        options: { responsive: true, maintainAspectRatio: false, cutout: '80%', plugins: { legend: { display: false } } }
    });
}

function populateVectors() {
    const data = [
        { label: 'SQL Injection', val: 45, col: 'bg-red-500' },
        { label: 'Cross-Site Scripting', val: 25, col: 'bg-yellow-500' },
        { label: 'Path Traversal', val: 15, col: 'bg-purple-500' },
        { label: 'Rate Limit Exceeded', val: 10, col: 'bg-primary' },
        { label: 'Bad Bot', val: 5, col: 'bg-zinc-600' },
    ];
    const container = document.getElementById('vector-legend');
    container.innerHTML = data.map(item => `<div class="flex items-center gap-3 text-xs"><span class="w-2 h-2 rounded-full ${item.col} flex-shrink-0"></span><span class="text-zinc-400 w-32 truncate">${item.label}</span><div class="flex-1 bg-white/5 h-1.5 rounded-full overflow-hidden"><div class="${item.col} h-full rounded-full" style="width:${item.val}%"></div></div><span class="font-mono text-white w-8 text-right">${item.val}%</span></div>`).join('');
}

function populateAlerts() {
    const alertStart = new Date();
    const alerts = [
        { severity: 'critical', color: 'red', msg: 'SQLi burst detected from NTC gateway - 48 payloads blocked in 12s', src: 'KTM-DC-01', time: alertStart },
        { severity: 'high', color: 'orange', msg: 'Bot traffic spike from Pokhara edge - 1,200 req/min from 3 IPs', src: 'PKR-Edge-02', time: new Date(alertStart - 120000) },
        { severity: 'medium', color: 'yellow', msg: 'Admin path probe from external IP 103.94.x.x - 6 attempts blocked', src: 'KTM-DC-01', time: new Date(alertStart - 480000) },
        { severity: 'low', color: 'blue', msg: 'LAL-DC-03 load threshold warning - CPU at 78%, scaling recommended', src: 'LAL-DC-03', time: new Date(alertStart - 900000) }
    ];
    const feed = document.getElementById('alerts-feed');
    const colors = { red: 'border-red-500/30 bg-red-500/5', orange: 'border-orange-500/30 bg-orange-500/5', yellow: 'border-yellow-500/30 bg-yellow-500/5', blue: 'border-blue-500/30 bg-blue-500/5' };
    const dotColors = { red: 'bg-red-500', orange: 'bg-orange-500', yellow: 'bg-yellow-500', blue: 'bg-blue-500' };
    feed.innerHTML = alerts.map((a, i) => `<div class="border-l-2 ${colors[a.color]} rounded-r-md px-4 py-3"><div class="flex justify-between items-start"><div class="flex items-start gap-2"><span class="w-1.5 h-1.5 rounded-full ${dotColors[a.color]} mt-1.5 flex-shrink-0"></span><p class="text-xs text-zinc-300">${a.msg}</p></div><span class="text-[10px] text-zinc-500 font-mono flex-shrink-0 ml-3" ${i===0?'id="first-alert-time"':''}>${i===0?'just now':formatTimeAgo(a.time)}</span></div><p class="text-[10px] text-zinc-600 mt-1 ml-4">${a.src} · ${a.severity.toUpperCase()}</p></div>`).join('');
    // Live timer for first alert
    setInterval(() => {
        const el = document.getElementById('first-alert-time');
        if (el) { const secs = Math.floor((Date.now() - alertStart.getTime()) / 1000); el.textContent = secs < 60 ? `${secs}s ago` : `${Math.floor(secs/60)}m ago`; }
    }, 1000);
}

function formatTimeAgo(date) {
    const secs = Math.floor((Date.now() - date.getTime()) / 1000);
    if (secs < 60) return `${secs}s ago`;
    return `${Math.floor(secs / 60)}m ago`;
}

function populateOrigin() {
    const countries = [
        { name: 'China', pct: 34, count: 626 },
        { name: 'Russia', pct: 22, count: 405 },
        { name: 'United States', pct: 16, count: 295 },
        { name: 'India', pct: 12, count: 221 },
        { name: 'Brazil', pct: 9, count: 166 },
        { name: 'Others', pct: 7, count: 129 }
    ];
    const container = document.getElementById('origin-bars');
    container.innerHTML = countries.map(c => `<div class="flex items-center gap-3 text-xs"><span class="text-zinc-400 w-24 truncate">${c.name}</span><div class="flex-1 bg-white/5 h-1.5 rounded-full overflow-hidden"><div class="bg-primary h-full rounded-full" style="width:${c.pct}%"></div></div><span class="font-mono text-zinc-300 w-16 text-right">${c.count.toLocaleString()} IPs</span></div>`).join('');
}

const rules = [
    { name: 'SQLi - Union Select', act: 'Blocked', badge: 'badge-red' },
    { name: 'XSS - Script Tag', act: 'Blocked', badge: 'badge-red' },
    { name: 'Rate Limit (Ncell Gateway)', act: 'Throttled', badge: 'badge-blue' },
    { name: 'Bad Bot (Scraper)', act: 'Blocked', badge: 'badge-red' }
];

function generateRow(isInitial = false) {
    const rule = rules[Math.floor(Math.random() * rules.length)];
    const ip = `${Math.floor(Math.random()*255)}.${Math.floor(Math.random()*255)}.${Math.floor(Math.random()*255)}.${Math.floor(Math.random()*255)}`;
    const dts = ['KTM-DC-01', 'PKR-Edge-02', 'LAL-DC-03'];
    const dest = dts[Math.floor(Math.random() * dts.length)];
    const time = new Date();
    if (isInitial) time.setMinutes(time.getMinutes() - Math.floor(Math.random() * 60));
    const timeStr = time.toLocaleTimeString([], { hour12: false });
    return `<tr class="table-row group"><td class="px-6 py-3 text-zinc-400 group-hover:text-zinc-300">${timeStr}</td><td class="px-6 py-3 text-white">${ip}</td><td class="px-6 py-3 text-zinc-300 font-sans text-xs">${rule.name}</td><td class="px-6 py-3 text-zinc-400 group-hover:text-white">${dest}</td><td class="px-6 py-3 text-right"><span class="badge ${rule.badge}">${rule.act}</span></td></tr>`;
}

function seedTable() { let rows = ''; for(let i=0; i<6; i++) rows += generateRow(true); dom.table.innerHTML = rows; }

function tickData() {
    state.total += Math.floor(Math.random() * 50);
    sparkData1.shift(); sparkData1.push(Math.random() * 10);
    sparkData2.shift(); sparkData2.push(Math.random() * 5);
    sparkData3.shift(); sparkData3.push(Math.random() * 20);
    sparkCharts.forEach(c => c.update());
    if(Math.random() > 0.6) {
        state.blocked += Math.floor(Math.random() * 3 + 1);
        state.bw += 0.01;
        dom.table.insertAdjacentHTML('afterbegin', generateRow());
        if(dom.table.children.length > 8) dom.table.removeChild(dom.table.lastElementChild);
    }
    state.latency = 1.1 + Math.random() * 0.3;
    updateDOM();
}

// --- BURP SUITE SIMULATION & TRAFFIC INTERCEPTOR ---
let burpPollingInterval = null;
let burpLogsData = ["> Proxy Offline", "> Click Start Proxy to begin..."];
let burpProxyActive = false;
let burpInterceptON = true;
let interceptedRequest = null;

function updateInterceptorUI() {
    const interceptPanel = document.getElementById('burp-interceptor-panel');
    const toggleBtn = document.getElementById('burp-intercept-toggle-btn');
    const statusDot = document.getElementById('burp-interceptor-status-dot');
    const flowStatus = document.getElementById('flow-status-text');
    
    if (!interceptPanel) return;
    
    if (burpProxyActive) {
        interceptPanel.classList.remove('opacity-50');
        statusDot.className = 'w-3 h-3 rounded-full bg-orange-500 animate-pulse shadow-[0_0_8px_#f97316]';
        toggleBtn.disabled = false;
        
        if (burpInterceptON) {
            toggleBtn.className = 'px-4 py-1.5 rounded text-xs font-semibold burp-orange-btn burp-orange-btn-active transition-all duration-150';
            toggleBtn.innerText = 'Intercept is ON';
            flowStatus.innerText = 'Proxy listening. Intercept mode active.';
        } else {
            toggleBtn.className = 'px-4 py-1.5 rounded text-xs font-semibold bg-white/5 border border-white/10 text-zinc-400 hover:bg-white/10 transition-all duration-150';
            toggleBtn.innerText = 'Intercept is OFF';
            flowStatus.innerText = 'Proxy active. Traffic passing through without intercept.';
        }
    } else {
        interceptPanel.classList.add('opacity-50');
        statusDot.className = 'w-3 h-3 rounded-full bg-zinc-600 shadow-none';
        toggleBtn.disabled = true;
        toggleBtn.className = 'px-4 py-1.5 rounded text-xs font-semibold bg-white/5 border border-white/10 text-zinc-500 cursor-not-allowed';
        toggleBtn.innerText = 'Intercept is OFF';
        flowStatus.innerText = 'Proxy offline. Start the proxy above to enable interception.';
        
        clearInterceptedRequest();
    }
}

function clearInterceptedRequest() {
    interceptedRequest = null;
    const rawEditor = document.getElementById('burp-raw-editor');
    const forwardBtn = document.getElementById('burp-forward-btn');
    const dropBtn = document.getElementById('burp-drop-btn');
    const queueBadge = document.getElementById('burp-queue-badge');
    const flowBurp = document.getElementById('flow-node-burp');
    const flowWaf = document.getElementById('flow-node-waf');
    const flowPulse1 = document.getElementById('flow-pulse-1');
    const flowPulse2 = document.getElementById('flow-pulse-2');
    
    if (rawEditor) {
        rawEditor.value = '';
        rawEditor.disabled = true;
        rawEditor.className = 'w-full bg-zinc-950/80 border border-white/10 rounded-md p-4 text-xs text-zinc-500 font-mono focus:outline-none focus:border-orange-500/50 transition-all h-64 resize-none shadow-inner leading-relaxed cursor-not-allowed';
    }
    
    if (forwardBtn) {
        forwardBtn.disabled = true;
        forwardBtn.className = 'px-4 py-1.5 bg-green-500/10 border border-green-500/20 text-green-500/50 rounded text-xs font-semibold cursor-not-allowed transition-all duration-150 flex items-center gap-1.5';
    }
    
    if (dropBtn) {
        dropBtn.disabled = true;
        dropBtn.className = 'px-4 py-1.5 bg-red-500/10 border border-red-500/20 text-red-500/50 rounded text-xs font-semibold cursor-not-allowed transition-all duration-150 flex items-center gap-1.5';
    }
    
    if (queueBadge) {
        queueBadge.classList.add('hidden');
    }
    
    if (flowBurp) flowBurp.className = 'w-8 h-8 rounded-md bg-white/5 border border-white/10 flex items-center justify-center text-zinc-400 text-[10px] font-mono flow-node';
    if (flowWaf) flowWaf.className = 'w-8 h-8 rounded-md bg-white/5 border border-white/10 flex items-center justify-center text-zinc-400 text-[10px] font-mono flow-node';
    if (flowPulse1) flowPulse1.className = 'flow-pulse';
    if (flowPulse2) flowPulse2.className = 'flow-pulse';
    
    const fireBtn = document.getElementById('sandbox-fire-btn');
    if (fireBtn) {
        fireBtn.innerText = 'Fire Payload';
        fireBtn.disabled = false;
    }
}

function addSecurityEvent(payload, signature, action, badgeClass) {
    const table = document.getElementById('event-table');
    if (!table) return;
    
    const timeStr = new Date().toLocaleTimeString([], { hour12: false });
    const ip = '103.94.189.2';
    const dest = 'KTM-DC-01';
    
    // Truncate payload for clean logs display
    let dispName = signature;
    if (payload) {
        const trunc = payload.length > 22 ? payload.substring(0, 19) + '...' : payload;
        dispName += ` ("${trunc}")`;
    }
    
    const newRow = `
        <tr class="table-row group">
            <td class="px-6 py-3 text-zinc-400 group-hover:text-zinc-300">${timeStr}</td>
            <td class="px-6 py-3 text-white">${ip}</td>
            <td class="px-6 py-3 text-zinc-300 font-sans text-xs">${dispName}</td>
            <td class="px-6 py-3 text-zinc-400 group-hover:text-white">${dest}</td>
            <td class="px-6 py-3 text-right"><span class="badge ${badgeClass}">${action}</span></td>
        </tr>
    `;
    
    table.insertAdjacentHTML('afterbegin', newRow);
    if(table.children.length > 8) table.removeChild(table.lastElementChild);
    
    // Add to metrics
    state.total += 1;
    if (action === 'Blocked') {
        state.blocked += 1;
    }
    updateDOM();
}

function processSignatureVerification(payload, responseContainer) {
    const isSQLi = /('|--|union|select|insert|update|delete|drop)/i.test(payload);
    const isXSS = /(<script|javascript:|onerror=|onload=|<img|<svg)/i.test(payload);
    const isLFI = /(\.\.\/|\.\.\\|etc\/passwd|boot\.ini)/i.test(payload);
    
    if (isSQLi || isXSS || isLFI) {
        let ruleName = '';
        if (isSQLi) ruleName = 'SQL Injection (OWASP CRS 942)';
        else if (isXSS) ruleName = 'Cross-Site Scripting (OWASP CRS 941)';
        else if (isLFI) ruleName = 'Local File Inclusion (OWASP CRS 930)';
        
        responseContainer.innerHTML = `
            <div class="absolute inset-0 bg-red-500/10"></div>
            <svg class="w-8 h-8 text-red-500 mb-2 relative z-10" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"></path>
            </svg>
            <h4 class="text-white font-bold text-sm relative z-10">Payload Blocked</h4>
            <p class="text-[10px] text-red-400 font-mono mt-1 relative z-10">${ruleName}</p>
        `;
        addSecurityEvent(payload, ruleName, 'Blocked', 'badge-red');
    } else {
        responseContainer.innerHTML = `
            <div class="absolute inset-0 bg-green-500/10"></div>
            <svg class="w-8 h-8 text-green-500 mb-2 relative z-10" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path>
            </svg>
            <h4 class="text-white font-bold text-sm relative z-10">Payload Allowed</h4>
            <p class="text-[10px] text-green-400 font-mono mt-1 relative z-10">No malicious signatures detected</p>
        `;
        addSecurityEvent(payload, 'Sandbox Safe Check', 'Allowed', 'badge-green');
    }
}

document.addEventListener('DOMContentLoaded', () => {
    const burpBtn = document.getElementById('burp-proxy-btn');
    const burpLogs = document.getElementById('burp-logs-container');
    const interceptToggleBtn = document.getElementById('burp-intercept-toggle-btn');
    const forwardBtn = document.getElementById('burp-forward-btn');
    const dropBtn = document.getElementById('burp-drop-btn');
    
    // Initialize UI on load
    updateInterceptorUI();
    
    if(burpBtn && burpLogs) {
        burpBtn.addEventListener('click', () => {
            const isStarting = burpBtn.innerText === 'Start Proxy';
            if(isStarting) {
                burpBtn.innerText = 'Stop Proxy';
                burpBtn.classList.replace('text-orange-400', 'text-red-400');
                burpBtn.classList.replace('bg-orange-500/20', 'bg-red-500/20');
                burpBtn.classList.replace('hover:bg-orange-500/30', 'hover:bg-red-500/30');
                burpLogsData = ["> Proxy Active on 127.0.0.1:8080", "> Waiting for browser request interception...", `[${new Date().toLocaleTimeString()}] > Proxy Gateway Connected`];
                renderBurpLogs();
                burpProxyActive = true;
                updateInterceptorUI();
                burpPollingInterval = setInterval(simulateBurpTraffic, 4000);
            } else {
                burpBtn.innerText = 'Start Proxy';
                burpBtn.classList.replace('text-red-400', 'text-orange-400');
                burpBtn.classList.replace('bg-red-500/20', 'bg-orange-500/20');
                burpBtn.classList.replace('hover:bg-red-500/30', 'hover:bg-orange-500/30');
                burpLogsData.push(`[${new Date().toLocaleTimeString()}] > Proxy Offline`);
                renderBurpLogs();
                burpProxyActive = false;
                updateInterceptorUI();
                clearInterval(burpPollingInterval);
            }
        });
    }
    
    if (interceptToggleBtn) {
        interceptToggleBtn.addEventListener('click', () => {
            if (!burpProxyActive) return;
            burpInterceptON = !burpInterceptON;
            updateInterceptorUI();
            burpLogsData.push(`[${new Date().toLocaleTimeString()}] Intercept is ${burpInterceptON ? 'ON' : 'OFF'}`);
            renderBurpLogs();
        });
    }
    
    if (forwardBtn) {
        forwardBtn.addEventListener('click', () => {
            if (!interceptedRequest) return;
            
            const rawEditor = document.getElementById('burp-raw-editor');
            const responseContainer = document.getElementById('sandbox-response');
            const fireBtn = document.getElementById('sandbox-fire-btn');
            
            const editedText = rawEditor.value;
            let forwardedPayload = '';
            
            try {
                const doubleCrlf = editedText.indexOf('\r\n\r\n');
                const doubleLf = editedText.indexOf('\n\n');
                let bodyIndex = -1;
                
                if (doubleCrlf !== -1) bodyIndex = doubleCrlf + 4;
                else if (doubleLf !== -1) bodyIndex = doubleLf + 2;
                
                if (bodyIndex !== -1) {
                    const bodyText = editedText.substring(bodyIndex).trim();
                    const bodyObj = JSON.parse(bodyText);
                    forwardedPayload = bodyObj.payload || '';
                } else {
                    const match = editedText.match(/"payload"\s*:\s*"([^"]+)"/);
                    forwardedPayload = match ? match[1] : '';
                }
            } catch (err) {
                const match = editedText.match(/"payload"\s*:\s*"([^"]+)"/);
                forwardedPayload = match ? match[1] : '';
            }
            
            if (!forwardedPayload) {
                forwardedPayload = interceptedRequest.originalPayload;
            }
            
            const wasModified = forwardedPayload !== interceptedRequest.originalPayload;
            
            const flowWaf = document.getElementById('flow-node-waf');
            const flowPulse2 = document.getElementById('flow-pulse-2');
            const flowStatus = document.getElementById('flow-status-text');
            
            if (flowPulse2) flowPulse2.className = 'flow-pulse pulse-green';
            
            clearInterceptedRequest();
            
            setTimeout(() => {
                const isSQLi = /('|--|union|select|insert|update|delete|drop)/i.test(forwardedPayload);
                const isXSS = /(<script|javascript:|onerror=|onload=|<img|<svg)/i.test(forwardedPayload);
                const isLFI = /(\.\.\/|\.\.\\|etc\/passwd|boot\.ini)/i.test(forwardedPayload);
                
                if (isSQLi || isXSS || isLFI) {
                    if (flowWaf) flowWaf.className = 'w-8 h-8 rounded-md flex items-center justify-center text-[10px] font-mono flow-node active-blocked';
                    flowStatus.innerHTML = '<span class="text-red-500">[BLOCKED]</span> Traffic forwarded to WAF and BLOCKED due to signatures.';
                    
                    let ruleName = '';
                    if (isSQLi) ruleName = 'SQL Injection (OWASP CRS 942)';
                    else if (isXSS) ruleName = 'Cross-Site Scripting (OWASP CRS 941)';
                    else if (isLFI) ruleName = 'Local File Inclusion (OWASP CRS 930)';
                    
                    responseContainer.innerHTML = `
                        <div class="absolute inset-0 bg-red-500/10"></div>
                        <svg class="w-8 h-8 text-red-500 mb-2 relative z-10" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"></path>
                        </svg>
                        <h4 class="text-white font-bold text-sm relative z-10">${wasModified ? 'Payload Modified & Blocked' : 'Payload Blocked'}</h4>
                        <p class="text-[10px] text-red-400 font-mono mt-1 relative z-10">${ruleName}</p>
                    `;
                    addSecurityEvent(forwardedPayload, ruleName + (wasModified ? ' [Modified]' : ''), 'Blocked', 'badge-red');
                } else {
                    if (flowWaf) flowWaf.className = 'w-8 h-8 rounded-md flex items-center justify-center text-[10px] font-mono flow-node active-success';
                    flowStatus.innerHTML = '<span class="text-green-500">[ALLOWED]</span> Traffic forwarded to WAF and ALLOWED successfully.';
                    
                    responseContainer.innerHTML = `
                        <div class="absolute inset-0 bg-green-500/10"></div>
                        <svg class="w-8 h-8 text-green-500 mb-2 relative z-10" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path>
                        </svg>
                        <h4 class="text-white font-bold text-sm relative z-10">${wasModified ? 'Payload Modified & Allowed' : 'Payload Allowed'}</h4>
                        <p class="text-[10px] text-green-400 font-mono mt-1 relative z-10">No malicious signatures detected in forwarded request</p>
                    `;
                    addSecurityEvent(forwardedPayload, 'Burp Proxy Forwarded' + (wasModified ? ' [Modified]' : ''), 'Allowed', 'badge-green');
                }
                
                burpLogsData.push(`[${new Date().toLocaleTimeString()}] <span class="text-green-400 font-bold">&gt;&gt; FORWARDED</span> Request ${wasModified ? 'MODIFIED' : 'without modifications'}`);
                renderBurpLogs();
            }, 600);
        });
    }
    
    if (dropBtn) {
        dropBtn.addEventListener('click', () => {
            if (!interceptedRequest) return;
            
            const responseContainer = document.getElementById('sandbox-response');
            const flowStatus = document.getElementById('flow-status-text');
            const flowWaf = document.getElementById('flow-node-waf');
            const flowPulse2 = document.getElementById('flow-pulse-2');
            
            if (flowPulse2) flowPulse2.className = 'flow-pulse pulse-red';
            if (flowWaf) flowWaf.className = 'w-8 h-8 rounded-md flex items-center justify-center text-[10px] font-mono flow-node active-blocked';
            flowStatus.innerHTML = '<span class="text-red-500">[DROPPED]</span> Request dropped by Proxy user. Traffic did not reach target.';
            
            responseContainer.innerHTML = `
                <div class="absolute inset-0 bg-red-950/20"></div>
                <svg class="w-8 h-8 text-red-500 mb-2 relative z-10" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                </svg>
                <h4 class="text-white font-bold text-xs relative z-10">Request Dropped</h4>
                <p class="text-[9px] text-zinc-500 font-mono mt-1 relative z-10">Dropped by Administrator via Burp Suite Proxy</p>
            `;
            
            addSecurityEvent(interceptedRequest.originalPayload, 'Burp Proxy dropped (Client Discard)', 'Dropped', 'badge-red');
            
            burpLogsData.push(`[${new Date().toLocaleTimeString()}] <span class="text-red-400 font-bold">X DROPPED</span> Request discarded by admin.`);
            renderBurpLogs();
            
            clearInterceptedRequest();
        });
    }

    function simulateBurpTraffic() {
        if(Math.random() > 0.4) {
            const methods = ['GET', 'POST', 'OPTIONS'];
            const method = methods[Math.floor(Math.random() * methods.length)];
            const paths = ['/login', '/api/v1/users', '/admin/dashboard', '/search?q=test'];
            const p = paths[Math.floor(Math.random() * paths.length)];
            burpLogsData.push(`[${new Date().toLocaleTimeString()}] Intercepted <span class="text-white">${method} ${p}</span>`);
            if(burpLogsData.length > 15) burpLogsData.shift();
            renderBurpLogs();
        }
    }
    
    function renderBurpLogs() { if(!burpLogs) return; burpLogs.innerHTML = burpLogsData.join('<br>'); burpLogs.scrollTop = burpLogs.scrollHeight; }
});

// --- PAYLOAD SANDBOX ---
document.addEventListener('DOMContentLoaded', () => {
    const fireBtn = document.getElementById('sandbox-fire-btn');
    const payloadInput = document.getElementById('sandbox-payload-input');
    const responseContainer = document.getElementById('sandbox-response');
    if(fireBtn && payloadInput && responseContainer) {
        fireBtn.addEventListener('click', () => {
            const payload = payloadInput.value.trim();
            if(!payload) return;
            
            if (burpProxyActive && burpInterceptON) {
                fireBtn.innerText = 'Intercepting...';
                fireBtn.disabled = true;
                
                responseContainer.innerHTML = `
                    <div class="absolute inset-0 bg-orange-500/5"></div>
                    <svg class="w-8 h-8 text-orange-500 mb-2 relative z-10 animate-pulse" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"></path>
                    </svg>
                    <h4 class="text-white font-bold text-xs relative z-10">Request Intercepted!</h4>
                    <p class="text-[9px] text-orange-400 font-mono mt-1 relative z-10">Awaiting Proxy Decision</p>
                `;
                
                setTimeout(() => {
                    const rawHttp = `POST /api/sandbox/fire HTTP/1.1\r
Host: target.nexus.local\r
Content-Type: application/json\r
User-Agent: Mozilla/5.0 (Windows; Nepal Enterprise Gateway)\r
X-Forwarded-For: 103.94.189.2\r
Cookie: session=NEXUS_ADMIN_77b3109a\r
Content-Length: ${JSON.stringify({ payload }).length}\r
\r
{\r
  "payload": "${payload.replace(/"/g, '\\"')}"\r
}`;
                    
                    interceptedRequest = {
                        originalPayload: payload,
                        source: 'sandbox'
                    };
                    
                    const rawEditor = document.getElementById('burp-raw-editor');
                    if (rawEditor) {
                        rawEditor.value = rawHttp;
                        rawEditor.disabled = false;
                        rawEditor.className = 'w-full bg-zinc-950/80 border border-orange-500/40 rounded-md p-4 text-xs text-orange-400 font-mono focus:outline-none focus:border-orange-500 transition-all h-64 resize-none shadow-inner leading-relaxed glow-orange cursor-text';
                        rawEditor.focus();
                    }
                    
                    const forwardBtn = document.getElementById('burp-forward-btn');
                    const dropBtn = document.getElementById('burp-drop-btn');
                    
                    if (forwardBtn) {
                        forwardBtn.disabled = false;
                        forwardBtn.className = 'px-4 py-1.5 bg-green-500/20 border border-green-500/40 text-green-400 hover:bg-green-500/30 rounded text-xs font-semibold transition-all duration-150 flex items-center gap-1.5 cursor-pointer';
                    }
                    
                    if (dropBtn) {
                        dropBtn.disabled = false;
                        dropBtn.className = 'px-4 py-1.5 bg-red-500/20 border border-red-500/40 text-red-400 hover:bg-red-500/30 rounded text-xs font-semibold transition-all duration-150 flex items-center gap-1.5 cursor-pointer';
                    }
                    
                    const queueBadge = document.getElementById('burp-queue-badge');
                    if (queueBadge) {
                        queueBadge.innerText = '1 Request Intercepted';
                        queueBadge.classList.remove('hidden');
                    }
                    
                    const flowStatus = document.getElementById('flow-status-text');
                    if (flowStatus) flowStatus.innerHTML = '<span class="text-orange-500">[INTERCEPTED]</span> Request paused in Burp Proxy. Edit raw HTTP and Forward/Drop.';
                    
                    const flowBurp = document.getElementById('flow-node-burp');
                    if (flowBurp) flowBurp.className = 'w-8 h-8 rounded-md flex items-center justify-center text-[10px] font-mono flow-node active-paused';
                    
                    const flowPulse1 = document.getElementById('flow-pulse-1');
                    if (flowPulse1) flowPulse1.className = 'flow-pulse pulse-orange';
                    
                    burpLogsData.push(`[${new Date().toLocaleTimeString()}] Intercepted <span class="text-orange-400 font-bold">POST /api/sandbox/fire</span> from 103.94.189.2`);
                    renderBurpLogs();
                }, 800);
            } else {
                fireBtn.innerText = 'Analyzing...';
                fireBtn.disabled = true;
                responseContainer.innerHTML = `<svg class="w-8 h-8 text-primary animate-spin mb-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"></path></svg><p class="text-xs text-primary animate-pulse">Running signature engine...</p>`;
                
                setTimeout(() => {
                    fireBtn.innerText = 'Fire Payload';
                    fireBtn.disabled = false;
                    processSignatureVerification(payload, responseContainer);
                }, 1200);
            }
        });
    }
});

// --- SQLMAP SIMULATION ---
document.addEventListener('DOMContentLoaded', () => {
    const sqlmapBtn = document.getElementById('sqlmap-btn');
    const sqlmapLogs = document.getElementById('sqlmap-logs');
    if (sqlmapBtn && sqlmapLogs) {
        sqlmapBtn.addEventListener('click', async () => {
            const targetInput = document.getElementById('sqlmap-target');
            const levelSelect = document.getElementById('sqlmap-level');
            const target = targetInput ? targetInput.value.trim() : 'http://target.local/api/users?id=1';
            const level = levelSelect ? levelSelect.value : '3';
            
            sqlmapBtn.innerText = 'Scanning...'; sqlmapBtn.disabled = true;
            sqlmapLogs.innerHTML = `<span class="text-blue-400">sqlmap -u "${target}" --random-agent --level ${level}</span><br>[*] starting @ ${new Date().toLocaleTimeString()}<br>`;
            
            if (isServedOverHttp) {
                try {
                    const res = await fetch('/api/sqlmap/scan', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ target, level })
                    });
                    if (res.ok) {
                        const data = await res.json();
                        sqlmapLogs.innerHTML = `<span class="text-blue-400">${data.command}</span><br>`;
                        let delay = 800;
                        data.lines.forEach((line, index) => {
                            setTimeout(() => {
                                sqlmapLogs.innerHTML += line + '<br>';
                                sqlmapLogs.scrollTop = sqlmapLogs.scrollHeight;
                                if (index === data.lines.length - 1) {
                                    sqlmapBtn.innerText = 'Run Scan';
                                    sqlmapBtn.disabled = false;
                                }
                            }, delay);
                            delay += 600 + Math.random() * 400;
                        });
                        return;
                    }
                } catch (err) {
                    console.error('[Backend] SQLMap scan fetch failed', err);
                }
            }
            
            // Local fallback
            const lines = [
                `[+] testing connection to the target URL "${target}"`,
                '[!] WAF/IPS identified: Nexus Enterprise WAF',
                '[*] checking if the target is vulnerable to SQL injection',
                '[*] testing evasion techniques (e.g. BETWEEN, RANDOMCASE)',
                '[-] target URL appears to be NOT injectable (blocked by WAF)'
            ];
            let delay = 800;
            lines.forEach((line, index) => {
                setTimeout(() => {
                    sqlmapLogs.innerHTML += line + '<br>';
                    sqlmapLogs.scrollTop = sqlmapLogs.scrollHeight;
                    if (index === lines.length - 1) {
                        sqlmapBtn.innerText = 'Run Scan';
                        sqlmapBtn.disabled = false;
                    }
                }, delay);
                delay += 700 + Math.random() * 500;
            });
        });
    }
});

// --- WAFW00F SIMULATION ---
document.addEventListener('DOMContentLoaded', () => {
    const wafw00fBtn = document.getElementById('wafw00f-btn');
    const wafw00fLogs = document.getElementById('wafw00f-logs');
    if (wafw00fBtn && wafw00fLogs) {
        wafw00fBtn.addEventListener('click', async () => {
            const targetInput = document.getElementById('wafw00f-target');
            const modeSelect = document.getElementById('wafw00f-mode');
            const target = targetInput ? targetInput.value.trim() : 'https://nepal-gateway.gov.np';
            const mode = modeSelect ? modeSelect.value : 'standard';
            
            wafw00fBtn.innerText = 'Analyzing...'; wafw00fBtn.disabled = true;
            
            let reason = 'Proprietary block page pattern match (HTTP 403)';
            if (mode === 'bypass') {
                reason = 'Detection skipped on active bypass filters verification';
            } else if (mode === 'aggressive') {
                reason = 'Cookie header signature "__nxs_shield" match & server banner verification';
            }
            
            wafw00fLogs.innerHTML = `<span class="text-purple-400">wafw00f ${target} ${mode === 'aggressive' ? '--aggressive' : ''}</span><br>`;
            
            if (isServedOverHttp) {
                try {
                    const res = await fetch('/api/wafw00f/analyze', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ target, mode })
                    });
                    if (res.ok) {
                        const data = await res.json();
                        wafw00fLogs.innerHTML = `<span class="text-purple-400">${data.command}</span><br>`;
                        let delay = 600;
                        data.lines.forEach((line, index) => {
                            setTimeout(() => {
                                wafw00fLogs.innerHTML += line + '<br>';
                                wafw00fLogs.scrollTop = wafw00fLogs.scrollHeight;
                                if (index === data.lines.length - 1) {
                                    wafw00fBtn.innerText = 'Analyze';
                                    wafw00fBtn.disabled = false;
                                }
                            }, delay);
                            delay += 600 + Math.random() * 300;
                        });
                        return;
                    }
                } catch (err) {
                    console.error('[Backend] Wafw00f scan fetch failed', err);
                }
            }
            
            // Local fallback
            const lines = [
                `[+] Checking for WAF presence on ${target}...`,
                '[+] Sending crafted HTTP requests to trigger security filters...',
                '[+] Analyzing server response headers and status codes...',
                '[+] WAF detected: Nexus Enterprise WAF',
                `[+] Reason: ${reason}`
            ];
            let delay = 600;
            lines.forEach((line, index) => {
                setTimeout(() => {
                    wafw00fLogs.innerHTML += line + '<br>';
                    wafw00fLogs.scrollTop = wafw00fLogs.scrollHeight;
                    if (index === lines.length - 1) {
                        wafw00fBtn.innerText = 'Analyze';
                        wafw00fBtn.disabled = false;
                    }
                }, delay);
                delay += 800 + Math.random() * 400;
            });
        });
    }
});

// --- GENERATE REPORT ---
document.addEventListener('DOMContentLoaded', () => {
    const reportBtn = document.getElementById('generate-report-btn');
    if(reportBtn) {
        reportBtn.addEventListener('click', async () => {
            reportBtn.innerText = 'Generating...'; reportBtn.disabled = true;
            
            if (isServedOverHttp) {
                try {
                    const res = await fetch('/api/report');
                    if (res.ok) {
                        const data = await res.json();
                        setTimeout(() => {
                            const w = window.open('', '_blank');
                            w.document.write(`<!DOCTYPE html><html><head><meta charset="UTF-8"><title>Nexus WAF Report</title><style>@import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');*{margin:0;padding:0;box-sizing:border-box}body{font-family:'Inter',sans-serif;background:#0a0a0b;color:#e4e4e7;padding:40px}.c{max-width:800px;margin:0 auto}.hd{border-bottom:1px solid rgba(255,255,255,0.1);padding-bottom:24px;margin-bottom:32px}.hd h1{font-size:24px;font-weight:600;color:white}.hd p{font-size:13px;color:#71717a;margin-top:4px}.bg{display:inline-block;padding:2px 8px;border-radius:4px;font-size:11px;font-weight:500;background:rgba(16,185,129,0.15);color:#10b981}.st{display:grid;grid-template-columns:repeat(4,1fr);gap:16px;margin-bottom:32px}.sc{background:rgba(255,255,255,0.03);border:1px solid rgba(255,255,255,0.08);border-radius:8px;padding:16px}.sc .l{font-size:11px;color:#71717a;text-transform:uppercase;letter-spacing:0.5px}.sc .v{font-size:22px;font-weight:600;color:white;margin-top:4px}table{width:100%;border-collapse:collapse;margin-top:16px}th,td{text-align:left;padding:10px 16px;border-bottom:1px solid rgba(255,255,255,0.05);font-size:13px}th{color:#71717a;font-weight:500;font-size:11px;text-transform:uppercase;letter-spacing:0.5px}td{color:#d4d4d8}.s{margin-bottom:32px}.s h2{font-size:16px;font-weight:600;color:white;margin-bottom:12px}.pb{background:#4F46E5;color:white;border:none;padding:8px 16px;border-radius:6px;font-size:13px;cursor:pointer;float:right}.pb:hover{background:#4338ca}@media print{.pb{display:none}body{background:white;color:#18181b}.sc{border-color:#e4e4e7}th{color:#52525b}td{color:#27272a}.hd h1,.s h2{color:#18181b}}</style></head><body><div class="c"><div class="hd"><button class="pb" onclick="window.print()">Print / Export PDF</button><h1>🛡️ Nexus WAF Security Report</h1><p>Generated: ${new Date(data.generatedAt).toLocaleString()} | Status: <span class="bg">${data.status}</span> | OWASP CRS: v3.3.2</p></div><div class="st"><div class="sc"><div class="l">Total Requests</div><div class="v">${data.summary.totalRequests}</div></div><div class="sc"><div class="l">Threats Blocked</div><div class="v">${data.summary.threatsBlocked}</div></div><div class="sc"><div class="l">Bandwidth</div><div class="v">${data.summary.bandwidth}</div></div><div class="sc"><div class="l">Avg Latency</div><div class="v">${data.summary.avgLatency}</div></div></div><div class="s"><h2>Top Threat Vectors</h2><table><thead><tr><th>Threat Type</th><th>Count</th><th>Percentage</th></tr></thead><tbody>${data.topThreats.map(t => `<tr><td>${t.type}</td><td>${t.count.toLocaleString()}</td><td>${t.percentage}</td></tr>`).join('')}</tbody></table></div><div class="s"><h2>WAF Configuration</h2><table><thead><tr><th>Metric</th><th>Value</th></tr></thead><tbody><tr><td>Active Rules</td><td>${data.activeRules} / ${data.totalRules}</td></tr><tr><td>OWASP Core Ruleset</td><td>v3.3.2</td></tr><tr><td>System Status</td><td>${data.status}</td></tr></tbody></table></div></div></body></html>`);
                            w.document.close();
                            reportBtn.innerText = 'Generate Report'; reportBtn.disabled = false;
                        }, 500);
                        return;
                    }
                } catch (err) {
                    console.error('[Backend] Report generation fetch failed', err);
                }
            }
            
            setTimeout(() => {
                const w = window.open('', '_blank');
                w.document.write(`<!DOCTYPE html><html><head><meta charset="UTF-8"><title>Nexus WAF Report</title><style>@import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');*{margin:0;padding:0;box-sizing:border-box}body{font-family:'Inter',sans-serif;background:#0a0a0b;color:#e4e4e7;padding:40px}.c{max-width:800px;margin:0 auto}.hd{border-bottom:1px solid rgba(255,255,255,0.1);padding-bottom:24px;margin-bottom:32px}.hd h1{font-size:24px;font-weight:600;color:white}.hd p{font-size:13px;color:#71717a;margin-top:4px}.bg{display:inline-block;padding:2px 8px;border-radius:4px;font-size:11px;font-weight:500;background:rgba(16,185,129,0.15);color:#10b981}.st{display:grid;grid-template-columns:repeat(4,1fr);gap:16px;margin-bottom:32px}.sc{background:rgba(255,255,255,0.03);border:1px solid rgba(255,255,255,0.08);border-radius:8px;padding:16px}.sc .l{font-size:11px;color:#71717a;text-transform:uppercase;letter-spacing:0.5px}.sc .v{font-size:22px;font-weight:600;color:white;margin-top:4px}table{width:100%;border-collapse:collapse;margin-top:16px}th,td{text-align:left;padding:10px 16px;border-bottom:1px solid rgba(255,255,255,0.05);font-size:13px}th{color:#71717a;font-weight:500;font-size:11px;text-transform:uppercase;letter-spacing:0.5px}td{color:#d4d4d8}.s{margin-bottom:32px}.s h2{font-size:16px;font-weight:600;color:white;margin-bottom:12px}.pb{background:#4F46E5;color:white;border:none;padding:8px 16px;border-radius:6px;font-size:13px;cursor:pointer;float:right}.pb:hover{background:#4338ca}@media print{.pb{display:none}body{background:white;color:#18181b}.sc{border-color:#e4e4e7}th{color:#52525b}td{color:#27272a}.hd h1,.s h2{color:#18181b}}</style></head><body><div class="c"><div class="hd"><button class="pb" onclick="window.print()">Print / Export PDF</button><h1>🛡️ Nexus WAF Security Report</h1><p>Generated: ${new Date().toLocaleString()} | Status: <span class="bg">Operational</span> | OWASP CRS: v3.3.2</p></div><div class="st"><div class="sc"><div class="l">Total Requests</div><div class="v">${state.total.toLocaleString()}</div></div><div class="sc"><div class="l">Threats Blocked</div><div class="v">${state.blocked.toLocaleString()}</div></div><div class="sc"><div class="l">Bandwidth</div><div class="v">${state.bw.toFixed(1)} GB</div></div><div class="sc"><div class="l">Avg Latency</div><div class="v">${state.latency.toFixed(1)} ms</div></div></div><div class="s"><h2>Top Threat Vectors</h2><table><thead><tr><th>Threat Type</th><th>Count</th><th>Percentage</th></tr></thead><tbody><tr><td>SQL Injection</td><td>${Math.floor(state.blocked*0.45).toLocaleString()}</td><td>45%</td></tr><tr><td>Cross-Site Scripting</td><td>${Math.floor(state.blocked*0.25).toLocaleString()}</td><td>25%</td></tr><tr><td>Path Traversal</td><td>${Math.floor(state.blocked*0.15).toLocaleString()}</td><td>15%</td></tr><tr><td>Rate Limit Exceeded</td><td>${Math.floor(state.blocked*0.10).toLocaleString()}</td><td>10%</td></tr><tr><td>Bad Bot</td><td>${Math.floor(state.blocked*0.05).toLocaleString()}</td><td>5%</td></tr></tbody></table></div><div class="s"><h2>WAF Configuration</h2><table><thead><tr><th>Metric</th><th>Value</th></tr></thead><tbody><tr><td>Active Rules</td><td>3 / 4</td></tr><tr><td>OWASP Core Ruleset</td><td>v3.3.2</td></tr><tr><td>System Status</td><td>Operational</td></tr></tbody></table></div></div></body></html>`);
                w.document.close();
                reportBtn.innerText = 'Generate Report'; reportBtn.disabled = false;
            }, 500);
        });
    }
});
